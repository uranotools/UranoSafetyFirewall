"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Safety/SafetyPlugin.ts
var SafetyPlugin_exports = {};
__export(SafetyPlugin_exports, {
  SafetyPlugin: () => SafetyPlugin
});
module.exports = __toCommonJS(SafetyPlugin_exports);
var import_PluginBase = require("@core/PluginBase");
var SafetyPlugin = class extends import_PluginBase.PluginBase {
  configStore;
  constructor(moduleConfig) {
    super(moduleConfig);
    this.configStore = moduleConfig;
  }
  async executeAction(action, payload) {
    const sessionId = payload._sessionId;
    if (!sessionId) {
      throw new Error("ID de sesi\xF3n no disponible en la herramienta.");
    }
    if (action === "getInfracctionsLogs") {
      try {
        const infracctions = await this.config.store.getSession("safety_infracctions") || 0;
        const isBanned = await this.config.store.getSession("safety_banned") || false;
        return {
          success: true,
          sessionId,
          infracctionsCount: infracctions,
          isBanned,
          status: isBanned ? "SUSPENDIDO" : infracctions > 0 ? "ADVERTIDO" : "LIMPIO"
        };
      } catch (e) {
        throw new Error(`Fallo al consultar logs de infracci\xF3n: ${e.message}`);
      }
    }
    if (action === "resetInfracctions") {
      try {
        await this.config.store.setSession("safety_infracctions", 0);
        await this.config.store.setSession("safety_banned", false);
        await this.config._callPlugin("Core", "SessionManager", "updateBadge", {
          sessionId,
          badge: {
            id: "safety-firewall-badge",
            label: "\u{1F6E1}\uFE0F Firewall Activo",
            color: "success",
            icon: "ShieldCheck"
          }
        });
        return {
          success: true,
          message: "Contador de advertencias e infracciones restablecido. Sesi\xF3n desbloqueada con \xE9xito."
        };
      } catch (e) {
        throw new Error(`Fallo al resetear infracciones: ${e.message}`);
      }
    }
    throw new Error(`Acci\xF3n "${action}" no soportada en el plugin de Safety.`);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SafetyPlugin
});
