"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// config.ts
var config_exports = {};
__export(config_exports, {
  UranoSafetyFirewallConfig: () => UranoSafetyFirewallConfig
});
module.exports = __toCommonJS(config_exports);
var UranoSafetyFirewallConfig = {
  name: "UranoSafetyFirewall",
  description: "Middleware h\xEDbrido de seguridad que intercepta inyecciones de prompts (jailbreaks) e inputs en la lista negra en caliente.",
  icon: "ShieldAlert",
  category: "Seguridad",
  // ── CONFIGURACIÓN DEL ENGINE MIDDLEWARE ──
  enginePlugin: true,
  engineHooks: [
    "preMessageProcess"
  ],
  // Habilitado en Desktop y Cloud
  inCloud: true,
  inDesktop: true,
  // ── VARIABLES DE ENTORNO EN CRIPTOGRAFÍA DE VAULT POR TENANT / USUARIO ──
  settings: [
    {
      name: "SAFETY_SENSITIVITY",
      type: "select",
      title: "Sensibilidad del Firewall",
      options: [
        { label: "Baja (Heur\xEDstica simple y Palabras prohibidas)", value: "low" },
        { label: "Media (Heur\xEDstica extendida contra inyecciones de prompt)", value: "medium" },
        { label: "Alta (Filtro estricto heur\xEDstico y bloqueo proactivo)", value: "high" }
      ],
      required: true
    },
    {
      name: "MAX_INFRACCTIONS_BEFORE_BAN",
      type: "number",
      title: "L\xEDmite de Infracciones permitidas",
      description: "Cantidad de consultas hostiles consecutivas toleradas antes de suspender al cliente. Default: 3",
      required: true
    },
    {
      name: "CUSTOM_BLOCKED_WORDS",
      type: "text",
      title: "Palabras y Temas Prohibidos",
      description: "Lista separada por comas de t\xE9rminos que causar\xE1n rechazo inmediato (ej: hacker, contrasena, gratis, bypass)"
    },
    {
      name: "SAFE_REJECTION_MESSAGE",
      type: "text",
      title: "Mensaje de Rechazo",
      description: "Mensaje que el bot retornar\xE1 al interceptar un input inseguro.",
      required: true
    },
    {
      name: "CUSTOM_BAN_MESSAGE",
      type: "text",
      title: "Mensaje de Bloqueo / Handoff",
      description: "Mensaje a mostrar si el usuario excede las infracciones y el chat queda suspendido.",
      required: true
    }
  ],
  // ── ESQUEMAS DE HERRAMIENTAS MCP EXPUESTAS AL AGENTE ──
  pluginSchemas: {
    Auditing: {
      actions: {
        getInfracctionsLogs: {
          label: "Consultar Infracciones del Chat",
          description: "Obtiene el historial de infracciones y el estado de advertencia acumulado en la sesi\xF3n de chat activa.",
          fields: []
        },
        resetInfracctions: {
          label: "Restablecer Advertencias",
          description: "Limpia el contador de advertencias del cliente para habilitar nuevamente la sesi\xF3n.",
          fields: []
        }
      }
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UranoSafetyFirewallConfig
});
