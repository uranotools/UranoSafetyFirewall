"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Engine/UranoSafetyFirewallEnginePlugin.ts
var UranoSafetyFirewallEnginePlugin_exports = {};
__export(UranoSafetyFirewallEnginePlugin_exports, {
  UranoSafetyFirewallEnginePlugin: () => UranoSafetyFirewallEnginePlugin
});
module.exports = __toCommonJS(UranoSafetyFirewallEnginePlugin_exports);
var import_EnginePluginBase = require("@core/EnginePluginBase");
var UranoSafetyFirewallEnginePlugin = class _UranoSafetyFirewallEnginePlugin extends import_EnginePluginBase.EnginePluginBase {
  // Lista estática de expresiones regulares para firmas comunes de Jailbreak / Prompt Injection
  static SENSITIVE_PATTERNS = [
    /ignore\s+(?:all\s+)?previous\s+instructions/i,
    /ignora\s+(?:todas\s+las\s+)?instrucciones\s+anteriores/i,
    /act\s+as\s+a\s+simulated/i,
    /actua\s+como\s+un\s+simulador/i,
    /new\s+system\s+directive/i,
    /nueva\s+directiva\s+del\s+sistema/i,
    /bypass\s+(?:the\s+)?safety/i,
    /desactivar\s+(?:el\s+)?filtro/i,
    /jailbreak/i,
    /unrestricted\s+mode/i,
    /modo\s+sin\s+restricciones/i,
    /system\s*[\:\-]\s*override/i
  ];
  static EXTENDED_PATTERNS = [
    /ignore\s+rules/i,
    /ignorar\s+reglas/i,
    /dime\s+la\s+contrase/i,
    /revelar\s+secreto/i,
    /reveal\s+secret/i,
    /system\s+prompt/i,
    /instrucciones\s+de\s+sistema/i
  ];
  async preMessageProcess(ctx, message) {
    const sensitivity = ctx.getSecret("SAFETY_SENSITIVITY") || "medium";
    const maxInfracctionsRaw = ctx.getSecret("MAX_INFRACCTIONS_BEFORE_BAN") || "3";
    const customBlockedWords = ctx.getSecret("CUSTOM_BLOCKED_WORDS") || "";
    const safeRejection = ctx.getSecret("SAFE_REJECTION_MESSAGE") || "Disculpa, no puedo responder a ese tipo de consulta. \xBFEn qu\xE9 m\xE1s te puedo ayudar?";
    const customBanMessage = ctx.getSecret("CUSTOM_BAN_MESSAGE") || "Has excedido el l\xEDmite de consultas inusuales. Esta conversaci\xF3n ha sido suspendida para asistencia humana.";
    const maxInfracctions = parseInt(maxInfracctionsRaw, 10);
    let userText = "";
    if (message && typeof message.content === "string") {
      userText = message.content;
    } else if (message && Array.isArray(message.content)) {
      userText = message.content.filter((part) => part.type === "text").map((part) => part.text).join(" ");
    }
    if (userText.trim().length === 0) {
      return { status: "continue" };
    }
    const isBanned = await ctx.store.getSession("safety_banned");
    if (isBanned) {
      ctx.addBadge({
        id: "safety-firewall-badge",
        label: "\u{1F512} Chat Suspendido",
        color: "danger",
        icon: "ShieldOff"
      });
      return {
        status: "intercepted",
        overrideResponse: customBanMessage
      };
    }
    let threatDetected = false;
    let threatReason = "";
    if (customBlockedWords.trim().length > 0) {
      const blockedWords = customBlockedWords.split(",").map((w) => w.trim().toLowerCase());
      const textLower = userText.toLowerCase();
      for (const word of blockedWords) {
        if (word.length > 0 && textLower.includes(word)) {
          threatDetected = true;
          threatReason = `Palabra Prohibida detectada: "${word}"`;
          break;
        }
      }
    }
    if (!threatDetected) {
      for (const pattern of _UranoSafetyFirewallEnginePlugin.SENSITIVE_PATTERNS) {
        if (pattern.test(userText)) {
          threatDetected = true;
          threatReason = "Firma de Jailbreak (Sensibilidad Baja/Media) detectada.";
          break;
        }
      }
    }
    if (!threatDetected && (sensitivity === "medium" || sensitivity === "high")) {
      for (const pattern of _UranoSafetyFirewallEnginePlugin.EXTENDED_PATTERNS) {
        if (pattern.test(userText)) {
          threatDetected = true;
          threatReason = "Firma de Jailbreak (Sensibilidad Media/Alta) detectada.";
          break;
        }
      }
    }
    if (!threatDetected && sensitivity === "high") {
      if (userText.toLowerCase().includes("system") && userText.toLowerCase().includes("ignore")) {
        threatDetected = true;
        threatReason = "Filtro estricto de sensibilidad Alta activado.";
      }
    }
    if (threatDetected) {
      let infracctionsCount = await ctx.store.getSession("safety_infracctions") || 0;
      infracctionsCount++;
      console.warn(`[UranoSafetyFirewall] Amenaza interceptada en sesi\xF3n ${ctx.sessionId}. Motivo: ${threatReason}. Infracciones: ${infracctionsCount}/${maxInfracctions}`);
      await ctx.store.setSession("safety_infracctions", infracctionsCount);
      ctx.injectSystemMessage(`[ALERTA DE SEGURIDAD: Entrada del usuario interceptada. Motivo: ${threatReason}. Intento ${infracctionsCount}/${maxInfracctions}]`);
      if (infracctionsCount >= maxInfracctions) {
        await ctx.store.setSession("safety_banned", true);
        ctx.addBadge({
          id: "safety-firewall-badge",
          label: "\u{1F512} Chat Suspendido",
          color: "danger",
          icon: "ShieldOff"
        });
        return {
          status: "intercepted",
          overrideResponse: customBanMessage
        };
      } else {
        ctx.addBadge({
          id: "safety-firewall-badge",
          label: `\u{1F6E1}\uFE0F Adv: Infracci\xF3n ${infracctionsCount}/${maxInfracctions}`,
          color: "warning",
          icon: "ShieldAlert"
        });
        return {
          status: "intercepted",
          overrideResponse: safeRejection
        };
      }
    }
    return { status: "continue" };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UranoSafetyFirewallEnginePlugin
});
